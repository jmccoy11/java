/*
 * Jonnathon McCoy
 * January 8, 2017
 * 
 * Package: pokerGame
 * Class: CardGameTest.java
 * 
 * This class the driver for the Java Review.
 * 
 * The purpose of this program is to create an array of individual
 * cards extending from the parent class PlayingCard to be
 * instantiated within an array so that it may be shuffled.
 */

package pokerGame;

import java.util.Random;

/**
 * This class is the driver for the Java Review.
 * 
 * The purpose of this program is to create an array of individual
 * cards extending from the parent class PlayingCard to be
 * instantiated within an array so that it may be shuffled.
 * 
 * @author Jonnathon McCoy
 * @version 1.0
 */
public class CardGameTest {

	public static Random rand = new Random();
	
	/**
	 * This is the entry point for the program.
	 * 
	 * @param args Command-line arguments
	 */
	public static void main(String[] args) {
		PlayingCard[] myDeck = new PlayingCard[52];
		
		createDeck(myDeck);
		printDeck(myDeck);
		
		System.out.println();
		System.out.println("--shuffling one time--");
		System.out.println();
		
		myDeck = shuffle(myDeck);
		printDeck(myDeck);
		
		System.out.println();
		System.out.println("--shuffling 100 times--");
		System.out.println();
		
		myDeck = shuffle(myDeck, 100);
		printDeck(myDeck);
		
		/*
		//Testing verification methods
		
		System.out.println();
		System.out.println("Creating a deck to check data validation");
		System.out.println();
		
		PlayingCard[] saniDeck = new PlayingCard[5];
		
		System.out.println("Card 0:");
		saniDeck[0] = new PlayingCard("green");
		
		System.out.println("Card 1:");
		saniDeck[1] = new PlayingCard("2");
		
		System.out.println("Card 2:");
		saniDeck[2] = new PlayingCardChild("red", "badgers", 3);
		
		System.out.println("Card 3:");
		saniDeck[3] = new PlayingCardChild("black", "hearts", -35);
		
		System.out.println("Card 4:");
		saniDeck[4] = new PlayingCardChild("red", "spades", 14);
		
		printDeck(saniDeck);
		*/
	} //main()
	
	/**
	 * Create a deck of 52 cards into the array. The first 13 indexes
	 * will be the red hearts suit, index 13-25 will be red diamonds,
	 * index 26-38 will be black spades, and index 39-51 will be
	 * black clubs.
	 * 
	 * @param deck - Array of PlayingCards.
	 */
	public static void createDeck(PlayingCard[] deck){
		for(int i = 0; i < deck.length; i++){
			if(i >= 0 && i <= 12){
				deck[i] = new PlayingCardChild("red", "hearts", i+1);
			}
			else if (i > 12 && i <= 25){
				deck[i] = new PlayingCardChild("red", "diamonds", i-12);
			}
			else if (i > 25 && i <= 38){
				deck[i] = new PlayingCardChild("black", "spades", i-25);
			}
			else{
				deck[i] = new PlayingCardChild("black", "clubs", i-38);
			}
		}
	} //createDeck()
	
	/**
	 * Print the contents of the PlayingCard array to the console.
	 * 
	 * @param deck - Array of PlayingCards.
	 */
	public static void printDeck(PlayingCard[] deck){
		for(int i = 0; i < deck.length; i++){
			System.out.println(deck[i].toString());
		}
	} //printDeck()
	
	/**
	 * Swap a random index object with another random index.
	 * 
	 * @param deck - Array of PlayingCards.
	 * @return - returns the new shuffled deck.
	 */
	public static PlayingCard[] shuffle(PlayingCard[] deck){
		int firstIndex = rand.nextInt(51);
		int secondIndex = rand.nextInt(51);
		
		while(firstIndex == secondIndex){
			secondIndex = rand.nextInt(51);
		}
		
		PlayingCard swap = deck[firstIndex];
		deck[firstIndex] = deck[secondIndex];
		deck[secondIndex] = swap;
		
		return deck;
	} //shuffle()
	
	/**
	 * Swap a random index object with another random index, n number
	 * of times.
	 * 
	 * @param deck - Array of PlayingCards.
	 * @param times - int number of times desired to shuffle and swap.
	 * @return - returns the new shuffled deck.
	 */
	public static PlayingCard[] shuffle(PlayingCard[] deck, int times){
		for(int i = 0; i < times; i++)
		{
			deck = shuffle(deck);
		}
		
		return deck;
	} //shuffle() overloaded
} //CardGameTest.java

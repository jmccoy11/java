/*
 * Jonnathon McCoy
 * January 8, 2017
 * 
 * Package: pokerGame
 * Class: PlayingCardChild.java
 * 
 * This class contains the constructor for the child class 
 * of the PlayingCard class.
 */

package pokerGame;

import java.util.Scanner;

/**
 * This class contains the constructor for the child class 
 * of the PlayingCard class.
 * 
 * @author Jonnathon McCoy
 * @version 1.0
 *
 */
public class PlayingCardChild extends PlayingCard{

	//fields
	String suit;
	int rank;
	
	Scanner console = new Scanner(System.in);
	String[] validSuit = {"hearts", "diamonds", "spades", "clubs"};
	String[] namedCards = {"jack", "queen", "king", "ace"};
	
	//constructor
	/**
	 * Parameterized constructor for PlayingCardChild.
	 * 
	 * @param color - for parent constructor, red or black
	 * @param suit - hearts, diamond, spades, or clubs
	 * @param rank - rank 1-13, 1 is Ace, 11 is Jack, 12 is Queen,
	 * 		and 13 is King.
	 */
	public PlayingCardChild(String color, String suit, int rank) {
		super(color);
		setSuit(suit);
		setRank(rank);
	}

	//methods
	/**
	 * Getter for suit.
	 * 
	 * @return String suit.
	 */
	public String getSuit() {
		return suit;
	}

	/**
	 * Setter for Suit.
	 * 
	 * @param suit Accepts String value for suit.
	 */
	public void setSuit(String suit) {
		String validSuit = validSuit(suit.toLowerCase());
		
		this.suit = validSuit;
	}
	
	/*
	 * Validate suit parameter to hearts, diamonds, spades, or clubs
	 * 
	 * @param suit - String suit needs to be hearts, diamonds, spades,
	 * 		or clubs.
	 * @return - validated String suit.
	 */
	private String validSuit(String suit){
		boolean isValid = false;
		
		while(!isValid){
			try{ // try/catch block to throw custom suit exception
				for(int i = 0; i < validSuit.length; i++)
				{
					if(validSuit[i].equalsIgnoreCase(suit))
					{
						isValid = true;
					}
				}
				
				if(!isValid) throw new InvalidSuitException();
			}
			catch(InvalidSuitException exc)
			{
				System.out.println("Please enter a valid card suit" +
						" of hearts, diamonds, clubs, or spades.");
				suit = console.nextLine();
			}
			catch(Exception exc){
				System.out.println("Something went wrong! " + exc 
						+ ".");
			}
		}
		
		return suit;
	}

	public int getRank() {
		return rank;
	}

	/**
	 * Setter for rank.
	 * 
	 * @param rank - int rank of card 1-13, 1 for Ace, 11 for Jack,
	 * 		12 for Queen, 13 for King.
	 */
	public void setRank(int rank) {
		int validRank = validRank(rank);
		
		this.rank = validRank;
	}
	
	/*
	 * Validate rank parameter to be 1-13. If not valid, ask user to
	 * 	enter 2-10, Jack, Queen, King, or Ace. Jack, Queen, King, and
	 * 	Ace will translate to 11, 12, 13, and 1 respectively.
	 * 
	 * @param rank - int rank of card 1-13, 1 for Ace, 11 for Jack,
	 * 		12 for Queen, 13 for King.
	 * @return - validated int rank.
	 */
	private int validRank(int rank){
		boolean valid = false;
		
		while(!valid){
			if(rank < 1 || rank > 13){
				System.out.println("Please enter a valid rank from "
						+ "2 to 10, Jack, Queen, King, or Ace");
				String newRank = console.nextLine();
				
				try{
					rank = Integer.parseInt(newRank);
				}
				catch (NumberFormatException exc){
					for(int i = 0; i < namedCards.length; i++){
						if(namedCards[i].equalsIgnoreCase(newRank))
						{
							if(newRank.equalsIgnoreCase("ace")) 
								rank = 1;
							else rank = 11 + i;
							valid = true;
						}
					}
				}
				catch (Exception exc){
					System.out.println("Something else went wrong! " 
							+ exc);
				}
			}
			else valid = true;
		}
			
		return rank;
	}

	/**
	 * String representation of the PlayingCard object.
	 * 1, 11, 12, and 13 will translate to Ace, Jack, Queen, or King
	 * respectively.
	 * 
	 * @return - Human-readable representation of the PlayingCard
	 *     object.
	 */
	public String toString() {
		String cardRank = Integer.toString(rank);
		
		if(rank == 1 || rank > 10 && rank <= 13)
		{
			switch(rank)
			{
				case 1: cardRank = "Ace";
						break;
				case 11: cardRank = "Jack";
						 break;
				case 12: cardRank = "Queen";
						 break;
				case 13: cardRank = "King";
						 break;
			} 
		}
		return cardRank + " of " + getSuit() + ".";	
	}	
}

package pokerGame;

/**
 * Custom Exception for handling an invalid suit.
 * 
 * @author Jonnathon McCoy
 * @version 1.0
 */
@SuppressWarnings("serial")
public class InvalidSuitException extends Exception{

	/**
	 * Default constructor for InvalidSuitException.
	 */
	public InvalidSuitException(){} //default InvalidSuitException()
	
	/**
	 * Parameterized constructor for InvalidSuitSelection
	 * to pass the message to the parent class Exception constructor.
	 * 
	 * @param message - String message to be passed to the parent
	 * class Exception constructor.
	 */
	public InvalidSuitException(String message){
		super(message);
	} //parameterized InvalidSuitException()
} //InvalidSuitException.java

package edu.greenriver.it.gameObjectPackage;

import edu.greenriver.it.cardsPackage.PlayingCard;

public abstract class CardGame {
	
	private String gameName;
	private String welcomeMessage;
	
	public CardGame(String name, String message){
		this.setGameName(name);
		this.setWelcomeMessage(message);
	}

	public abstract void shuffle();
	public abstract PlayingCard deal();
	public abstract void playRound();

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public String getWelcomeMessage() {
		return welcomeMessage;
	}

	public void setWelcomeMessage(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}
}

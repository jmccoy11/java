package edu.greenriver.it.gameTestPackage;

import edu.greenriver.it.gameObjectPackage.BlackjackGame;

public class BlackjackDriver {

	public static void main(String[] args) {
		
		BlackjackGame game = new BlackjackGame();
		
		//game.printDeck(game.getDeck());
		
		game.playRound();
	}

}
